# Initial page

## Referenced books

1. https://www.manning.com/books/kubernetes-in-action

2. https://www.nginx.com/resources/library/cloud-native-devops-with-kubernetes


